<?PHP
#-----------------------------------------------------------------------------------------
# HUNGARYAN LANGUAGE FILE FOR PWA+PHP
#-----------------------------------------------------------------------------------------
$LANG_MISSING_VAR_H1="Hiba: Egy vagy t�bb sz�ks�ges v�ltoz� hi�nyzik a config.php fileb�l!";
$LANG_MISSING_VAR_H3="K�rem ind�tsa �jra az install.php konfigur�ci�s scriptet.";
$LANG_PERM_FILTER="Hozz�f�r�s megtagadva! Sz�r� bekapcsol�sa sz�ks�ges.";
$LANG_GALLERIES="Picasa Gal�ri�k";
$LANG_GALLERY="Gal�ria";
$LANG_IMAGES="k�pek";
$LANG_PRIVATE="Priv�t";
$LANG_PUBLIC="Nyilv�nos";
$LANG_WHERE="Hely";
$LANG_ACCESS="Hozz�f�r�s";
$LANG_PHOTOS_IN="k�p az";
$LANG_ALBUMS="albumok";
$LANG_BACK="vissza az albumokhoz";
$LANG_PAGE="Oldal";
$LANG_GET="el�r";
$LANG_GENERATED="Az oldalt k�sz�tette";
?>