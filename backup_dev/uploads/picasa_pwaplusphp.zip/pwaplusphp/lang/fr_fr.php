<?PHP
#-----------------------------------------------------------------------------------------
# FRENCH LANGUAGE FILE FOR PWA+PHP
#-----------------------------------------------------------------------------------------
$LANG_MISSING_VAR_H1="Erreur: Il manque au moins une variable au fichier config.php!";
$LANG_MISSING_VAR_H3="Veuillez relancer le programme de configuration install.php.";
$LANG_PERM_FILTER="Acc�s interdit. Il faut fournir un filtre.";
$LANG_GALLERIES="Galleries Picasa";
$LANG_GALLERY="Gallerie";
$LANG_IMAGES="images";
$LANG_PRIVATE="Priv�";
$LANG_PUBLIC="Public";
$LANG_WHERE="Chemin d'acc�s";
$LANG_ACCESS="Acc�s";
$LANG_PHOTOS_IN="photos dans";
$LANG_ALBUMS="albums";
$LANG_BACK="retour � la liste des albums";
$LANG_PAGE="Page";
$LANG_GET="Obtenir";
$LANG_GENERATED="Page g�n�r�e par";
?>
