﻿<?PHP
#-----------------------------------------------------------------------------------------
# SPANISH (MEXICO) LANGUAGE FILE FOR PWA+PHP
#-----------------------------------------------------------------------------------------
$LANG_MISSING_VAR_H1="Error: Faltan una o m&aacute;s variables requeridas de config.php!";
$LANG_MISSING_VAR_H3="Por favor vuelva a correr el script de configuraci&oacute;n install.php.";
$LANG_PERM_FILTER="Permiso denegado. Se requiere filtro.";
$LANG_GALLERIES="Galer&iacute;as Picasa";
$LANG_GALLERY="Galer&iacute;a";
$LANG_IMAGES="im&aacute;genes";
$LANG_PRIVATE="Privado";
$LANG_PUBLIC="P&uacute;blico";
$LANG_WHERE="Lugar";
$LANG_ACCESS="Accesso";
$LANG_PHOTOS_IN="fotos en";
$LANG_ALBUMS="&aacute;lbumes";
$LANG_BACK="regresar a lista de &aacute;lbum";
$LANG_PAGE="P&aacute;gina";
$LANG_GET="Obtener";
$LANG_GENERATED="P&aacute;gina generada por";
?>
