<?PHP
#-----------------------------------------------------------------------------------------
# DK DANISH LANGUAGE FILE FOR PWA+PHP
#-----------------------------------------------------------------------------------------
$LANG_MISSING_VAR_H1="Fejl: En eller flerer variabler mangler i config.php!";
$LANG_MISSING_VAR_H3="Du skal k�re install.php konfiguration scriptet igen.";
$LANG_PERM_FILTER="Adgang Ikke Tilladt.  Du beh�ver et filter.";
$LANG_GALLERIES="Picasa Gallerier";
$LANG_GALLERY="Galleri";
$LANG_IMAGES="Billeder";
$LANG_PRIVATE="Private";
$LANG_PUBLIC="Public";
$LANG_WHERE="Hvor";
$LANG_ACCESS="Access";
$LANG_PHOTOS_IN="Billeder i";
$LANG_ALBUMS="Albummer";
$LANG_BACK="Tilbage til album list";
$LANG_PAGE="Side";
$LANG_GET="Hent";
$LANG_GENERATED="Side Genereret af";
?>
