﻿<?PHP
#-----------------------------------------------------------------------------------------
# CATALAN LANGUAGE FILE FOR PWA+PHP
#-----------------------------------------------------------------------------------------
$LANG_MISSING_VAR_H1="Error: Falta una o m&eacute;s variables necessàries al config.php!";
$LANG_MISSING_VAR_H3="Si us plau, torna a executar l'script de configuraci&oacute; install.php.";
$LANG_PERM_FILTER="Perm&iacute;s denegat. Cal un filtre.";
$LANG_GALLERIES="Galeries Picasa";
$LANG_GALLERY="Galeria";
$LANG_IMAGES="imatges";
$LANG_PRIVATE="Privat";
$LANG_PUBLIC="P&uacute;blic";
$LANG_WHERE="Lloc";
$LANG_ACCESS="Acc&eacute;s";
$LANG_PHOTOS_IN="fotos en";
$LANG_ALBUMS="&agrave;lbums";
$LANG_BACK="torna a la llista d'&agrave;lbums";
$LANG_PAGE="P&agrave;gina";
$LANG_GET="Obtenir";
$LANG_GENERATED="P&agrave;gina generada per";
?>
